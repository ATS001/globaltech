<?php


// :  
$config_array['host'] = 'localhost'; 
// :  
$config_array['pass'] = 'soniko'; 
// :  
$config_array['database'] = 'eonape'; 
// :  
$config_array['user'] = 'dg'; 
// rachid: test new config 
$config_array['rachid'] = 'ana'; 
// secret1:  
$config_array['secret1'] = 'nex secret v1 new line'; 
// secret2: test de commentaire 
$config_array['secret2'] = 'nex secret v1 new line'; 
// secret4: comment for secret 4 
$config_array['secret4'] = 'nex secret v1 new line'; 


// test1: Comment for test  
$config_array['test1'] = 'Val test 1 new'; 
// test2: Comment for test  
$config_array['test2'] = 'Val test 2 new'; 
// test3: Comment for test  
$config_array['test3'] = 'Val test 3 new'; 
