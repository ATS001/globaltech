<?php 
session_start(); 
ob_start("ob_gzhandler");




@include_once(MPATH_INCLUDES.'auto_loader.php');
	$autoloadManager = new AutoloadManager();
	$autoloadManager->setSaveFile(MPATH_INCLUDES.'autoload.php');
	$autoloadManager->addFolder(MPATH_INCLUDES);
	$autoloadManager->addFolder(MPATH_LIBRARIES);
	$autoloadManager->addFolder(MPATH_MODULES);
    
    $autoloadManager->register();
// ---------------------------------------------------
// Check Configuration Exist 
// Si la configuration de base n'existe pas définir la variable GOTO_INSLALL 
// pour traitement niveau application.
// ---------------------------------------------------  

if(MCfg::get('host') == NULL){

  	define('GOTO_INSTALL', 1);
}else { 


// ---------------------------------------------------
//  Configuration Database
// ---------------------------------------------------
	 
     $db   =  new MySQL();
     

/**
 * Define Sys Infos
 */
     define('SYS_TITRE',    MCfg::get('sys_titre'));
     define('CLIENT_TITRE', MCfg::get('client_titre'));
    

}

 ?>