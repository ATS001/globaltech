<?php 


function udt($index,$new_value){
  $reading = fopen('var_1.php', 'r');
  $writing = fopen('var_1.tmp', 'w');

  $replaced = false;

  while (!feof($reading)) {
    $line = fgets($reading);
    if (stristr($line,$index)) {

      
      $line = "$"."config_array['$index'] = '".$new_value."';\n";
      $replaced = true;
    }
    fputs($writing, $line);
  }
  fclose($reading); fclose($writing);
// might as well not overwrite the file if we didn't replace anything
  if ($replaced) 
  {
    rename('var_1.tmp', 'var_1.php');
    echo "good $index \n";
  } else {
    unlink('var_1.tmp');
  }

}

function set($index,$new_value,$coment=""){
	//check if index not exist
 $config_array = array();
 require('var_1.php');
 
 
 if(array_key_exists($index , $config_array))
 {
   echo('Le parametre <b>'.$index.'</b> exist dans la configuration de base !'." \n");
 }else{
  $line_coment = "// $index: $coment \n";   
  $line = $line_coment ."$"."config_array['$index'] = '".$new_value."'; \n";
  file_put_contents('var_1.php', $line, FILE_APPEND | LOCK_EX);


  
  echo "good $index \n";
} 






}


set('secret1','nex secret v1 new line');
set('secret2','nex secret v1 new line',"test de commentaire");
set('secret4','nex secret v1 new line','comment for secret 4');
udt('theme1','nex theme');

?>