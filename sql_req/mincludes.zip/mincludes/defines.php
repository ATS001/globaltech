<?php
/**
 * @package    MRN_ERP
 *
 * @copyright  Copyright (C) 2011 - 2015 Africa Telecom Solution, SARL. All rights reserved.
 * @license    
 */

defined('_MEXEC') or die;




// Defines
define('SLASH',          '/');
define('MPATH_ROOT',          MPATH_BASE);
define('MPATH_SITE',          MPATH_ROOT);
define('MPATH_CONFIGURATION', MPATH_ROOT);
define('MPATH_ADMINISTRATOR', MPATH_ROOT . SLASH . 'administrator'. SLASH);
define('MPATH_LIBRARIES',     MPATH_ROOT . SLASH . 'libraries'. SLASH);
define('MPATH_PLUGINS',       MPATH_ROOT . SLASH . 'plugins'. SLASH);
define('MPATH_INSTALLATION',  MPATH_ROOT . SLASH . 'installation'. SLASH);
define('MPATH_THEMES',        MPATH_BASE . SLASH . 'templates'. SLASH);
define('MPATH_INCLUDES',      MPATH_BASE . SLASH . 'mincludes'. SLASH);
define('MPATH_MODULES',       MPATH_BASE . SLASH . 'modules'. SLASH);
define('MPATH_MSG',           MPATH_BASE . SLASH . 'msg'. SLASH);
define('MPATH_AJAX',          MPATH_BASE . SLASH . 'ajax'. SLASH);
define('MPATH_CACHE',         MPATH_BASE . SLASH . 'cache'. SLASH);
define('MPATH_TEMP',          MPATH_BASE . SLASH . 'temp'. SLASH);
define('MPATH_UPLOAD',        MPATH_BASE . SLASH . 'upload'. SLASH);
define('MPATH_IMG',           MPATH_BASE . SLASH . 'img'. SLASH);
define('MPATH_EXPORT_MOD',    MPATH_BASE . SLASH . 'sql_req/import'. SLASH);


