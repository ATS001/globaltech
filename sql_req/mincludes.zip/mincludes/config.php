<?php






//Class Using Config
//
/**
* 
*/
class MCfg 
{
  const CONF_FILE = 'var.php';

    //Get Config Element
  static public function get($key)
  {

   $config_array = array();
   require(self::CONF_FILE);


   if(!array_key_exists($key , $config_array) || !isset($config_array[$key]))
   {
         //Merror::load('Le parametre <b>'.$key.'</b> n\'existe pas ou non configuré');
     return null;
   } 
   return $config_array[$key] ;

 }

 static public function get_all_cfg()
 {
   $config_array = array();
   require(self::CONF_FILE);
   return $config_array;
 }

   //Update the config element
 static public function udt($index,$new_value){
   $reading = fopen(self::CONF_FILE, 'r');
   $writing = fopen(self::CONF_FILE.'.tmp', 'w');

   $replaced = false;

   while (!feof($reading)) {
    $line = fgets($reading);
    if (stristr($line,$index)) {
      $line = "$"."config_array['$index'] = '".$new_value."';\n";
      $replaced = true;
    }
    fputs($writing, $line);
  }
  fclose($reading); fclose($writing);
// might as well not overwrite the file if we didn't replace anything
  if ($replaced){
    rename(self::CONF_FILE.'.tmp', self::CONF_FILE);

  } else {
    unlink(self::CONF_FILE.'.tmp');
  }

}
   //Set the config element
static public function set($index,$new_value,$coment=""){
  //check if index not exist
 $config_array = array();
 require(MPATH_INCLUDES.'var_1.php');


 if(array_key_exists($index , $config_array))
 {
   echo('Le parametre <b>'.$index.'</b> exist dans la configuration de base !'." \n");
 }else{
  $line_coment = "// $index: $coment \n";   
  $line = $line_coment ."$"."config_array['$index'] = '".$new_value."'; \n";
  file_put_contents(MPATH_INCLUDES.'var_1.php', $line, FILE_APPEND | LOCK_EX);


  
  echo "good $index \n";
} 






}

static public function setarray($listvaleur){
  //check if index not exist
 $config_array = array();
 require(MPATH_INCLUDES.'var_1.php');

 while ( $element = current($listvaleur)) {
  if(array_key_exists(key($listvaleur) , $config_array))
  {

    $fichier=MPATH_INCLUDES."var.php"; 

        //ouverture en lecture et modification 
    $text=fopen($fichier,'r') or die("Fichier manquant"); 
    $contenu=file_get_contents($fichier); 
    $contenuMod=str_replace("$"."config_array['".key($listvaleur)."'] = '".$config_array[key($listvaleur)]."';","$"."config_array['".key($listvaleur)."'] = '".$element."';" , $contenu); 
    fclose($text); 

        //ouverture en écriture 
    $text2=fopen($fichier,'w+') or die("Fichier manquant"); 
    fwrite($text2,$contenuMod); 
    fclose($text2); 

        // echo('Le parametre <b>'.$config_array[key($listvaleur)].'</b> exist dans la configuration de base !'." \n");
  }else{
    $line_coment = "// $index: $coment \n";   
    $line = $line_coment ."$"."config_array['".key($listvaleur)."'] = '".$element."'; \n";
    file_put_contents(MPATH_INCLUDES.'var_1.php', $line, FILE_APPEND | LOCK_EX);


  } 
  next($listvaleur);
}







}
}

?>